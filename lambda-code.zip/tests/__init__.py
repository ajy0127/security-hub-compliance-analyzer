"""Tests for the SecurityHub SOC 2 Email Reporter."""
